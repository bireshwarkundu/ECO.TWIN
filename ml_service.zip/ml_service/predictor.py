from datetime import datetime
from ml_service.model_loader import models
import numpy as np

def predict_pollutant(pollutant, features):
    try:
        m = models[pollutant]

        base = m["main"].predict([features])[0]

        hour = datetime.now().hour
        month = datetime.now().month

        hourly_adj = m["hourly"][hour]
        monthly_adj = m["monthly"][month-1]

        return round(base + hourly_adj + monthly_adj, 2)

    except:
        return float(models[pollutant]["global"])