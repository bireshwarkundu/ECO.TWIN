from ml_service.simulator import simulate_conditions

def optimize_policy():
    scenarios = [
        {"traffic":80,"green":20,"industry":90,"wind":2},
        {"traffic":60,"green":30,"industry":80,"wind":3},
        {"traffic":50,"green":40,"industry":70,"wind":4},
    ]

    best = None
    best_score = 1e9

    for s in scenarios:
        res = simulate_conditions(s)
        score = res["pm25"] + res["pm10"]

        if score < best_score:
            best_score = score
            best = s

    return {
        "policy": best,
        "expected_aqi_drop": round(best_score/5,1)
    }