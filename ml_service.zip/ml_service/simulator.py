from ml_service.predictor import predict_pollutant

def simulate_conditions(inputs):
    traffic = inputs["traffic"]
    green = inputs["green"]
    industry = inputs["industry"]
    wind = inputs["wind"]

    features = [traffic, green, industry, wind]

    result = {}

    for p in ["pm25","pm10","no2","co","o3","so2","no"]:
        result[p] = predict_pollutant(p, features)

    return result