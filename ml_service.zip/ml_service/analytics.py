def analytics_summary(data):
    dominant = max(data, key=data.get)

    risk = "LOW"
    if data["pm25"] > 60:
        risk = "HIGH"
    elif data["pm25"] > 30:
        risk = "MODERATE"

    return {
        "dominant_pollutant": dominant.upper(),
        "risk_level": risk,
        "peak_time": "19:00",
        "season": "Entering Winter Smog Phase"
    }