from fastapi import FastAPI
from pydantic import BaseModel
import requests

from ml_service.config import OPENAQ_API_KEY, LOCATION_ID
from ml_service.simulator import simulate_conditions
from ml_service.optimizer import optimize_policy
from ml_service.analytics import analytics_summary

app = FastAPI()


# ---------------- AQI CALCULATION (INDIAN CPCB) ---------------- #
def calculate_aqi(pm25):
    if pm25 <= 30:
        return int(pm25 * 50 / 30)
    elif pm25 <= 60:
        return int(50 + (pm25 - 30) * 50 / 30)
    elif pm25 <= 90:
        return int(100 + (pm25 - 60) * 100 / 30)
    elif pm25 <= 120:
        return int(200 + (pm25 - 90) * 100 / 30)
    else:
        return 300


# ---------------- LIVE DATA ENDPOINT ---------------- #
@app.get("/live-data")
def live_data():
    headers = {"X-API-Key": OPENAQ_API_KEY}
    pollutants = {}

    try:
        # Fetch sensors at location
        loc_url = f"https://api.openaq.org/v3/locations/{LOCATION_ID}"
        loc_res = requests.get(loc_url, headers=headers, timeout=10).json()

        sensors = loc_res.get("results", [])[0].get("sensors", [])

        for sensor in sensors:
            name = sensor["parameter"]["name"]
            last = sensor.get("lastMeasurement")

            # Use latest measurement if available
            if last and last.get("value") is not None:
                pollutants[name] = last["value"]
            else:
                # fallback to latest historical reading
                sensor_id = sensor["id"]
                latest_url = f"https://api.openaq.org/v3/sensors/{sensor_id}/measurements?limit=1"
                latest_res = requests.get(latest_url, headers=headers, timeout=10).json()

                results = latest_res.get("results", [])
                if results:
                    pollutants[name] = results[0]["value"]

        # ---------- FILTER ONLY REQUIRED POLLUTANTS ----------
        allowed = ["pm25", "pm10", "no", "no2", "co", "o3", "so2"]
        pollutants = {k: pollutants[k] for k in allowed if k in pollutants}

        # ---------- CONVERT CO µg/m³ → ppm ----------
        if "co" in pollutants:
            pollutants["co"] = round(pollutants["co"] / 1145, 2)

        # ---------- ROUND VALUES ----------
        pollutants = {k: round(v, 2) for k, v in pollutants.items()}

        # ---------- COMPUTE AQI ----------
        if "pm25" in pollutants:
            pollutants["aqi"] = calculate_aqi(pollutants["pm25"])

        return pollutants

    except Exception as e:
        return {"error": str(e)}


# ---------------- 72 HOUR FORECAST ---------------- #
@app.get("/forecast")
def forecast():
    base = {"traffic": 100, "green": 15, "industry": 100, "wind": 2}

    forecast = []
    for i in range(72):
        value = simulate_conditions(base)["pm25"]
        forecast.append(round(value, 2))

    return forecast


# ---------------- RELATIVE RATIOS ---------------- #
@app.get("/ratios")
def ratios():
    base = {"traffic": 100, "green": 15, "industry": 100, "wind": 2}
    data = simulate_conditions(base)

    total = sum(data.values())
    return {k: round(v / total * 100, 1) for k, v in data.items()}


# ---------------- SIMULATION INPUT MODEL ---------------- #
class SimulationInput(BaseModel):
    traffic: float
    green: float
    industry: float
    wind: float


# ---------------- POLICY SANDBOX SIMULATION ---------------- #
@app.post("/simulate")
def simulate(inputs: SimulationInput):
    return simulate_conditions(inputs.dict())


# ---------------- AI SCENARIO OPTIMIZER ---------------- #
@app.get("/optimize")
def optimize():
    return optimize_policy()


# ---------------- RESEARCH ANALYTICS ---------------- #
@app.get("/analytics")
def analytics():
    base = {"traffic": 100, "green": 15, "industry": 100, "wind": 2}
    data = simulate_conditions(base)
    return analytics_summary(data)